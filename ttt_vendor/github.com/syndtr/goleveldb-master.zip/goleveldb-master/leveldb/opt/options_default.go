//go:build !darwin
// +build !darwin

package opt

var (
	DefaultOpenFilesCacheCapacity = 500
)
